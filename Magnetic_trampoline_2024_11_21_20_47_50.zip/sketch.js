let rectButton, ellipseButton, keyButton;
let buttonSize = 80;
 
function setup() {
  createCanvas(400, 400);
  rectButton = createButton("Button 1");
  ellipseButton = createButton("Button 2");
  keyButton = createButton("'D'Key");
 
  rectButton.position(60, 200);
  rectButton.size(buttonSize, 70);
  rectButton.mousePressed(rectButtonClicked);
 
  ellipseButton.position(300, 200);
  ellipseButton.size(buttonSize, 70);
  ellipseButton.mousePressed(ellipseButtonClicked);
 
}
 
function draw() {
  background(220);
 
  fill(50, 70, 120);
  rect(60, 200, buttonSize, 70);
  fill(50, 70, 120);
  ellipse(300 + buttonSize /2, 150, buttonSize, 70);
 
  fill(200);
  textSize(20);
  textAlign(CENTER);
  text("Press 'D' near Button to activate", width /2 , 50);
 
   if (keyIsPressed && key === 'd') {
	fill (10, 25, 200);
	rect (60, 200, buttonSize, 70);
	text ("Doom", 240, 233)
  } 'else'; {
	fill (200);
	rect (60, 200, buttonSize, 70);
	
  }
}
 
function rectButtonClicked(){
  alert ("Tornado Approaching!");
}
function ellipseButtonClicked(){
  alert ("Volcano Erupting!")
}
function keyPressed(){
  if(key === 'd'){
	if (mouseX > 50 && mouseX < 50 + buttonSize && mouseY > 250 && mouseY < 250 + 50){
  	alert("Doom");
	}
  }
}
 
 

