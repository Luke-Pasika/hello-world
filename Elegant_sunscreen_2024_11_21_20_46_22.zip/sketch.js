function setup() {
  createCanvas(600, 600);
}

function draw() {
  background(0, 150, 150);
   print('Sun Direction')
  
  //Ground
  fill(0, 255, 0);
   rect(0, 550, 600, 50);
  
  //trees
  fill(255, 115, 0);
  rect (100, 400, 50, 150);
  fill(0, 255, 0)
  rect(60, 315, 140, 100);
  
  //house
  fill(255, 115, 0);
  rect(300, 300, 280, 250);
  fill(50, 55, 0);
  triangle(300, 300, 580, 300, 433, 150)
  rect(413, 430, 50, 120);
  fill(255);
  rect(320, 320, 50, 50);
  rect(500, 320, 50, 50);
  fill(0);
  line(440, 550, 440, 430);
 
  
  
  //sun
  push();
  translate(mouseX, mouseY);
  fill(255, 255, 0);
  circle(0, 0, 70);
  pop();
  let x = random(0, 600);
  let y = random(0, 600);
  
  //clouds
  fill(255);
  ellipse(70, 180, 300, 60);
  ellipse(300, 100, 300, 80);
  ellipse(450, 200, 300, 100);
  ellipse(120, 240, 300, 70);
  ellipse(500, 80, 300, 40);
  
  
  // Snow Particles
  let angle = frameCount * 0.01
  rotate(angle);
  translate(50, 50);
  fill(255);
  scale(1.2, 0.6);
  circle(200, 200, 70);
  
  let = frameCount * 0.02
  rotate(angle);
  translate(0, 25);
  fill(255);
  scale(0.5, 1.3);
  circle(200, 200, 70);
  
  let = frameCount * 0.03
  rotate(angle);
  translate(0, 25);
  fill(0, 255, 255);
  scale(1.5, 2.6);
  circle(200, 200, 70);
  
  let = frameCount * 0.04
  rotate(angle);
  translate(0, 25);
  fill(0, 255, 255);
  scale(0.3, 1.5);
  circle(200, 200, 70);
  
  let = frameCount * 0.05
  rotate(angle);
  translate(0, 25);
  fill(0, 255, 255);
  scale(1.2, 0.7);
  circle(200, 200, 70);
  
  let = frameCount * 0.06
  rotate(angle);
  translate(0, 25);
  fill(0, 255, 255);
  circle(200, 200, 70);
  
  let = frameCount * 0.07
  rotate(angle);
  translate(0, 25);
  fill(255);
  scale(1.3, 0.5);
  circle(200, 200, 70);
  
  let = frameCount * 0.08
  rotate(angle);
  translate(0, 25);
  fill(0, 255, 255);
  scale(3.5, 0.75);
  circle(200, 200, 70);
  
 
  
}






