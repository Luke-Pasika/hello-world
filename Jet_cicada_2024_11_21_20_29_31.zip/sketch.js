


let x = 400;
let y = 400;
let goLeft = false;
function setup() {
  createCanvas(800, 800);
}

function draw() {
  background(0);
  //Walls
  fill(0);
  strokeWeight(10);
  stroke(0, 0, 255);
  rect(10, 8, 780, 50);
  rect(10, 60, 50, 250);
  rect(10, 480, 50, 250);
  rect(10, 740, 780, 50);
  rect(740, 480, 50, 250);
  rect(740, 60, 50, 250);
  rect(70, 250, 60, 60);
  rect(680, 250, 60, 60);
  rect(70, 480, 200, 50);
  rect(550, 480, 180, 50);

 
  stroke(0);
  strokeWeight(2);
 
 
  if(goLeft == false){
    x= x+1;
  }
  if(goLeft == true){
  x= x-1;  
}
  if(x>800)
    {
      goLeft= true;
    }
  if(x<0)
    {
      goLeft= false;
    }
  //Inky
  fill(0, 185, 255);
  stroke(0, 185, 255);
  rect(x-50, y-50, 55, 55);
  fill(255)
  rect(x-50, y-50, 10, 10);
  rect(x-5, y-50, 10, 10);
  fill(0)
  rect (x-50, y-35, 10, 40);
  rect (x-5, y-35, 10, 40);
  rect (x-27, y-35, 10, 40);
  //Pinky
  fill(255, 0, 185);
  stroke(255, 0, 185);
  rect (x+65, y+65, 55, 55);
  fill(255)
  rect(x+65, y+65, 10, 10);
  rect(x+110, y+65, 10, 10);
  fill(0)
  rect(x+65, y+80, 10, 40);
  rect(x+110, y+80, 10, 40);
  rect(x+87, y+80, 10, 40);
  //Blinky
  fill(255, 0, 0);
  stroke(255, 0, 0);
  rect(x+20, y, 55, 55);
  fill(255)
  rect(x+20, y, 10, 10);
  rect(x+65, y, 10, 10);
  fill(0)
  rect(x+20, y+13, 10, 40);
  rect(x+65, y+13, 10, 40);
  rect(x+42, y+13, 10, 40);
  //Clyde
  fill(255, 185, 0);
  stroke(255, 185, 0);
  rect(x-140, y, 55, 55);
  fill(255)
  rect(x-140, y, 10, 10);
  rect(x-95, y, 10, 10);
  fill(0)
  rect(x-140, y+13, 10, 40);
  rect(x-95, y+13, 10, 40);
  rect(x-118, y+13, 10, 40);
  
  //PacMan
  fill(200, 210, 0);
  stroke(0)
  strokeWeight(5)
  circle(400, 230, 100);
  fill(0)
  circle(380, 205, 10);
  circle(420, 205, 10);
  rect(215, 235, 230, 20 )
  //text
  stroke(200, 210, 0);
  strokeWeight(5);
  textSize(40)
  textAlign(CENTER);
  text('Pac-Man', 400, 320);
}


  





